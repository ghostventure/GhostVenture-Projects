Ghost Surfer Linux Installation Manager (x86_64)

Run this manager as your regular user, without sudo:
  ./ghost-surfer-manager

It identifies the Linux distribution, derivative family, version, architecture,
and glibc; then selects a compatible Ghost Surfer release from the live catalog.
It checks the release SHA-256 before handing it to the app installer.

Commands: install (default), update, reinstall, uninstall, status, launch, plan.
Use ./ghost-surfer-manager help for options. Unverified distributions require
review and the explicit --allow-unverified option. Alpine/musl and non-x86_64
systems are not supported by this manager build.
