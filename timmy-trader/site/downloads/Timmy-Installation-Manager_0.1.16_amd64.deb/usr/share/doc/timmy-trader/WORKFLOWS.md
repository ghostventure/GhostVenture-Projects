# Timmy Workflows

This document is the durable workflow map for keeping Timmy trading, scanning, syncing watchlists, and publishing source updates without missing required checks.

Do not put broker usernames, passwords, MFA codes, API keys, tokens, account IDs, or screenshots into chat, issues, commits, or CI logs. Live brokerage checks stay local because they require the configured machine and authorized Webull credentials.

## 1. Change Validation Workflow

Use this after every source, config, strategy, broker, watchlist, packaging, or documentation change.

1. Run the Python test suite:

```bash
.venv/bin/pytest
```

2. Run the smoke test:

```bash
.venv/bin/python scripts/smoke_test.py
```

3. Rebuild the desktop ELF when GUI, packaging, broker, config, or launch behavior changed:

```bash
scripts/build_elf.sh
```

4. If the running process must use the new build, save settings and use the
   GUI's `Power Cycle`, or exit Timmy normally before launching again:

```bash
scripts/launch_timmy.sh
```

Do not terminate Timmy by a broad process-name match. A per-user OS lock at
`${XDG_CONFIG_HOME:-~/.config}/timmy-trader/timmy-instance.lock` prevents a
second launch even if it selects another runtime home. An active process keeps
using its current build until it exits; the lock file may remain, but its OS
lock is released automatically.

5. From the native GUI, use `Power Cycle` to save settings and relaunch the current installed executable after the current instance exits.

6. Inspect `/tmp/timmy-launch.log` and `timmy-crash.log` if the process does not stay up.

## 2. Native GUI Workflow

Use this layout contract when adding or moving Timmy controls.

1. Keep `Overview` as a high-level workflow snapshot only: pipeline counts, current target/mode, buying power, broker guard state, audit status, and watchlist focus.

2. Keep detailed scanner tables and selected-symbol output in `Scanner`.

3. Keep model controls, signal mix, readiness gates, and eligible-symbol detail in `Strategy`.

4. Keep order controls, executable queue, fractional state, broker/risk gates, and live/paper actions in `Execution`.

5. Keep account route status, buying-power source, live switches, preview freshness, and raw broker responses in `Broker`.

6. Keep event counts, signed-event coverage, protected runtime-file status, and recent execution history in `Audit`.

7. Do not duplicate full tables, broker logs, audit trails, or execution controls on `Overview`; surface only the summary values needed to see whether the workflow is moving.

## 3. Trading Desk Workflow Standard

Use this standard before adding new widgets, reports, or automation controls.

1. Every widget must have one owner tab. Summary values may appear on
   `Overview`, but full controls, detailed tables, logs, and report bodies
   belong only to their owner tab.

2. The owner tabs are:

```text
Account Setup -> profile, credentials, account selection, local profile files
Market Pulse -> symbol universe, scans, movement ranking, watchlist sync
Today's Guardrails -> strategy style, signal mix, readiness gates, patterns
Orders Ready -> queue, paper/live controls, fractional routing, order actions
Broker Desk -> account route, cash/buying power, preview and submit responses
Trade Log -> integrity chain, protected-file state, execution event history
Account Readiness -> Account Check, status hooks, restart/watchdog readiness
Trading Scoreboard -> Paper vs Live Scorecard and trading performance
```

3. When a tab needs data owned by another tab, show a compact read-only
   summary and point the operator to the owner tab through the workflow state,
   not by copying the original widget.

4. Standardize status language across the GUI:

```text
Ready -> the gate is current and usable
Guarded -> Timmy can run, but a live or automated path is blocked
Blocked -> Timmy must not proceed until the issue is fixed
Unknown -> Timmy has not collected enough evidence to classify the state
Stale -> the last evidence exists but is too old for the current decision
```

5. Standardize action language:

```text
Account Check -> read current account state without changing broker state
Verify -> validate profile, credential, or configuration correctness
Preview -> broker rehearsal for the exact current order payload
Submit -> broker order placement
Sync -> update a Timmy-owned external watchlist or cache
Power Cycle -> restart the current Timmy executable
```

6. Account Readiness hooks should collect data from the existing runtime state
   and expose only gate summaries: Timmy process, market data, broker auth,
   cash/buying power, watchlist sync, orders ready, trade log state, last scan,
   last broker response, and watchdog status.

7. Desktop notification hooks should use standardized event classes:

```text
critical -> live submit, broker rejection, trade log warning, duplicate process
warning -> stale data, cash/buying power unavailable, preview rejected
info -> paper fill, scan complete, account check passed, power cycle complete
```

8. The one-click Account Check contract should run read-only checks by default:
   duplicate process, profile presence, broker credential verification state,
   data freshness, market session, generated watchlists, orders ready, trade
   log chain, protected-file integrity, and publication boundary. It must not
   place orders, clear journals, rotate account targets, or mutate watchlists
   unless the operator explicitly chooses a repair action.

9. The Paper vs Live Scorecard hook should compare plan count, paper fills,
   live previews, live submits, rejects, skipped trades, P/L fields when
   available, and blocker categories by symbol, session, and strategy profile.

10. The Trading Scoreboard hook should summarize win rate, expectancy, average
   risk/reward, drawdown, symbol follow-through, time-of-day behavior,
   volatility regime, rejection rate, and strategy profile results. It should
   read from journals and execution events instead of creating a second source
   of truth.

11. Maintain `docs/UPGRADE_MANIFEST.md` as the registry that maps planned upgrades to their owner module, owner tab, status, and verification contract.

## 4. Runtime Reliability Workflow

Use this standard when changing Timmy's launch, automation, broker, scanner, or GUI behavior.

1. Timmy should have one active process per Linux user, across `TIMMY_HOME` values. Power Cycle waits for the current process to exit; a manual relaunch is refused while the user's OS lock remains held.

2. Startup should tolerate missing runtime files by recreating safe defaults, then logging recoverable state in the GUI instead of crashing.

3. Runtime state belongs in local files with hardened permissions. Credentials, profile data, audit keys, journals, generated watchlists, package output, and caches must stay out of the public source mirror.

4. Broker-dependent actions must degrade to a guarded state when account data, buying power, market session, quote freshness, preview freshness, or live switches are not current.

5. Scanner, strategy, execution, broker, and audit views should render from shared runtime state instead of each tab maintaining separate copies of the same logic.

6. Any GUI or trading-flow change must pass compile, pytest, smoke test, ELF rebuild, process restart, and a visual check of the changed tabs before it is treated as ready.

7. Failures that Timmy can control should become blocked/guarded UI states with journaled evidence. Uncontrolled failures include power loss, network outage, broker outage, OS kill, corrupted disk, and revoked credentials.

8. Account Readiness belongs in `trend_trader.runtime_health`. It is the
   shared contract for single-process visibility, safe-mode state,
   credential-expiry warnings, readiness blockers, crash recovery, and
   pre-market Account Checks.

9. Settings import, export, versioning, and rollback belong in `trend_trader.settings_profile`. Exports skip sensitive keys by default; private local snapshots use `0600` file permissions and `.timmy-config-versions` uses `0700`.

10. Use the watchdog when Timmy should be kept alive outside a terminal session:

```bash
.venv/bin/python scripts/timmy_watchdog.py --home /path/to/timmy-home
```

11. Use safe mode when Timmy must boot for inspection but live automation must be forced off:

```bash
TIMMY_SAFE_MODE=1 .venv/bin/python scripts/timmy_watchdog.py --safe-mode --home /path/to/timmy-home
```

Safe mode forces:

```text
TRADER_MODE=paper
TRADER_LIVE=0
WEBULL_ENABLE_LIVE_ORDERS=0
AUTO_START_LIVE_ON_MARKET_OPEN=0
```

12. Use the check-only watchdog path before unattended operation. It writes a
    private watchdog event and returns non-zero when Account Readiness has
    blockers:

```bash
.venv/bin/python scripts/timmy_watchdog.py --check-only --home /path/to/timmy-home
```

13. Do not display raw secrets, usernames, passwords, tokens, API keys, account
    IDs, or unmasked crash excerpts in Account Readiness, watchdog logs,
    exported settings, docs, tests, or GUI surfaces.

## 5. Strategy/Risk Intelligence Workflow

Use this before changing thresholds or allowing a new automation path to influence live orders.

1. Strategy presets belong in `trend_trader.strategy_presets`. Each preset should describe the profile, config overrides, enabled patterns, and risk notes so Timmy can apply a coherent trading style instead of scattered one-off settings.

2. Failure classification, trade-ready reason inspection, why-no-trade rollups, and backtest/replay summaries belong in `trend_trader.diagnostics`.

3. Circuit breakers, per-symbol exposure, sector/industry exposure, liquidity, spread/slippage, volatility regime, market trend, and event/earnings risk checks belong in `trend_trader.market_guards`.

4. Run the trade-ready inspector against each candidate before loosening thresholds. It should identify whether the candidate is ready, blocked by strategy, blocked by order planning, blocked by account/risk state, or waiting on an unknown guard.

5. Treat daily loss and max drawdown circuit breakers as account-level hard stops.

6. Treat per-symbol, sector, and industry exposure as portfolio-level concentration guards.

7. Treat liquidity, spread/slippage, volatility regime, market trend, and known news/event/earnings risk as market-quality guards before trusting a signal.

8. Backtest/replay output should be summarized into a small readiness record before any GUI or automation flow uses it.

## 6. Live Brokerage Workflow

Use this before relying on unattended live brokerage.

1. Confirm local live switches in `.env`:

```text
TRADER_MODE=live
TRADER_LIVE=1
WEBULL_ENABLE_LIVE_ORDERS=1
AUTO_START_LIVE_ON_MARKET_OPEN=1
ENABLE_EQUITY_FRACTIONAL_TRADING=1
```

2. Confirm the cash/buying-power Account Check succeeds from Timmy. If buying
   power is unavailable, live submission should be treated as blocked.

3. To configure or change accounts, use the native GUI `Setup` tab. Enter the
   Webull App Key, App Secret, account ID, region, endpoint, and live switches,
   run `Verify Keys`, save only after verification passes, run `Account Check`,
   choose the desired masked account label, then run `Account Check` again
   before switching target back to `Live`.

4. Confirm Timmy has exactly one running process for the active `TIMMY_HOME`.

5. Confirm the current market session and quote freshness are valid for the symbols being traded.

6. Confirm order sizing gates before market open:

```text
MAX_POSITIONS
MAX_DAILY_TRADES
MAX_SYMBOL_DAILY_TRADES
ORDER_COOLDOWN_MINUTES
RISK_PER_TRADE_USD
WEBULL_MAX_ORDER_NOTIONAL_USD
WEBULL_MAX_ORDER_QUANTITY
MAX_ENTRY_CASH_PCT
```

7. Confirm Timmy is producing executable plans. Scanning alone is not the same as order placement.

8. Confirm broker rejections are logged and reviewed before loosening any thresholds.

## 7. Actual Trade Placement Workflow

Use this for the real order lifecycle. This workflow is local-only and must not be moved into GitHub Actions.

1. Timmy scans the current active watchlist and rotating market batch.

2. Timmy writes the generated watchlists:

```text
active-watchlist.txt
movement-watchlist.txt
trade-ready-watchlist.txt
quiet-watchlist.txt
```

3. Timmy builds executable plans only for symbols that pass strategy, score, market, cooldown, daily-cap, per-symbol-cap, risk, notional, quantity, buying-power, and asset-class gates.

4. In `Live / Auto`, the native app runs this order path without requiring the operator to be present:

```text
decision cycle -> exact Webull preview -> live submit -> execution event -> account/buying-power refresh
```

5. The Live Auto path is currently limited to US equities/ETFs. It uses an exact Webull preview receipt on the same adapter and normalized payload before the one placement call; the raw `submit_order()` adapter method fails closed.

6. The live guards that must remain intentional are:

```text
TRADER_MODE=live
TRADER_LIVE=1
WEBULL_ENABLE_LIVE_ORDERS=1
WEBULL_REQUIRE_PREVIEW=1
WEBULL_ACCOUNT_ID configured locally
AUTO_START_LIVE_ON_MARKET_OPEN=1 (saved Live Auto opt-in)
```

7. The native app performs the exact-current-plan preview immediately before submit in `Live / Auto`; it requires a saved Live Auto opt-in and Account Check. The preview is always required even if a legacy setting was previously changed to `0`.

8. Timmy can run separate paper and live automation lanes. `Paper lane`
   journals simulated trades for learning while `Live / Auto` uses the guarded
   Webull preview/submit path. A blocked or rejected live lane should not stop
   paper evidence collection, and paper activity must not bypass live broker
   checks.

9. Every live broker result is appended to `execution-events.jsonl` with the submitted plan context. Use the event log to confirm whether an order was submitted, rejected, or blocked.

10. Automation lane results are feedback data. Above-expectation outcomes,
    below-expectation outcomes, rejected live attempts, blocked lanes, no-plan
    cycles, paper P/L, and open paper notional should remain available in the
    local audit/training trail for future market adaptation.

11. After a submitted or rejected order, Timmy should refresh buying power/account state before the next cycle. If account refresh fails, treat the next live cycle as blocked until the broker state is readable again.

12. If no live trade occurs, classify the miss before changing settings:

```text
no executable plan
stale market data
market closed
buying power unavailable
symbol blocked by whitelist or asset-class guard
score below threshold
cooldown or daily cap active
fractional minimum notional not met
Webull preview rejected
Webull submit rejected
```

13. Webull Desktop is not part of the placement path. It is only a viewer for account, order, position, and watchlist state that came from Webull.

## 8. Broker Operations Workflow

Use this for account-side state that happens after Timmy previews or submits an order.

1. Reconcile Timmy's local execution events against broker read-back before trusting the next unattended live cycle.

2. Track fills from broker order state, including partial fills, so position size and average entry can be rebuilt from broker truth.

3. Monitor open broker orders separately from executable plans. An open order for a symbol should block duplicate same-symbol entries until it is filled, canceled, rejected, or expired.

4. Compare broker positions against Timmy's position book. Open positions should block duplicate entries unless a future strategy explicitly supports adding to a position.

5. Keep cancel/replace as a guarded scaffold by default. Generated cancel/replace payloads must remain dry-run unless a future reviewed broker adapter explicitly enables live cancel/replace.

6. Keep trailing-stop and partial-profit behavior as risk metadata until a live broker implementation is deliberately added. Metadata is allowed to describe the intended risk model; it must not silently create extra live orders.

7. Refresh the broker session when it is disconnected, unauthenticated, stale, nearing token expiry, or carrying a recent broker error.

8. After every Webull watchlist sync, perform a read-back verification by list name and symbol set. Report only names, counts, missing symbols, and extra symbols.

9. Treat unmatched active broker orders as warnings. They may be manual Webull orders or stale Timmy state, and they should be reviewed before relaxing duplicate-trade guards.

10. Treat missing broker read-back for a submitted local event as a warning unless the local event is a block, preview, preview-required, or rejection.

## 9. Fractional-First Trading Workflow

Use this when a symbol is too expensive for a whole-share order or when buying power is limited.

1. Keep fractional trading enabled:

```text
ENABLE_EQUITY_FRACTIONAL_TRADING=1
WEBULL_MIN_EQUITY_FRACTIONAL_NOTIONAL_USD=5
WEBULL_EQUITY_FRACTIONAL_QUANTITY_DECIMALS=5
```

2. Timmy should prefer a fractional US equity order when the calculated whole-share quantity is below one share and the notional meets the configured minimum.

3. Whole-share limit orders remain the fallback when fractional trading is disabled or the fractional order fails broker validation.

4. Treat repeated fractional-order broker rejections as a configuration issue, not a signal issue.

## 10. All-Market Scanning Workflow

Use this to keep Timmy looking across the U.S. listed universe instead of a fixed watchlist.

1. Enable the all-US movement scan by selecting its universe. This scan is separate from automatic active-watchlist rotation:

```text
WATCHLIST_UNIVERSE=all-us
WATCHLIST_UNIVERSE_BATCH_SIZE=100
```

2. When cached candles are stale, Timmy scans a rotating batch from the configured universe (100 symbols by default). It can scan even when `ENABLE_WATCHLIST_ROTATION=0`. The scan uses daily bars and is partial; provider limits and errors can delay or leave coverage incomplete. This scan alone does not change the active strategy watchlist or make every symbol tradable.

3. To separately rotate the active custom watchlist based on the candidate pool, set `ENABLE_WATCHLIST_ROTATION=1`. Review its active-list and broker whitelist settings before use.

4. Timmy ships `trend_trader/resources/us-listed-symbols.csv` as a warm-start snapshot. Use it when the runtime cache is missing so discovery does not start from the small default list.

5. The mutable runtime cache remains `timmy-watchlist-universe.txt`; it is refreshed from Nasdaq Trader when reachable and kept out of source control.

6. `active-watchlist.txt` is the custom list Timmy trades from.

7. `movement-watchlist.txt` tracks symbols with enough activity to monitor.

8. `trade-ready-watchlist.txt` tracks active symbols whose strategy signal is eligible before broker/risk submission checks.

9. `quiet-watchlist.txt` tracks symbols removed because activity fell below the quiet threshold.

10. If Timmy scans but does not trade, check `trade-ready-watchlist.txt`, strategy scores, broker risk gates, buying power, cooldowns, and rejection history.

## 11. Webull Watchlist Sync Workflow

Use this to reflect Timmy's generated lists in Webull account-side watchlists. Webull Desktop is only the viewer.

1. Enable sync locally:

```text
WEBULL_SYNC_WATCHLISTS=1
WEBULL_ACTIVE_WATCHLIST_NAME=Timmy Active
WEBULL_MOVEMENT_WATCHLIST_NAME=Timmy Movement
WEBULL_TRADE_READY_WATCHLIST_NAME=Timmy Trade Ready
WEBULL_QUIET_WATCHLIST_NAME=Timmy Quiet Removed
```

2. Timmy creates or updates only the configured Timmy-managed watchlists.

3. Existing non-Timmy Webull watchlists must be left alone.

4. After a scan cycle, verify account-side counts with a read-back check. Report only names, counts, and symbols; do not expose internal IDs or credentials.

5. If Webull Desktop does not immediately show the changes, refresh or restart Webull Desktop. The account-side API read-back is the source of truth.

## 12. Publication Workflow

Use this when updating the public mirror.

1. Copy source-only files to the mirror and exclude credentials, runtime state, generated dependencies, build output, journals, cache, locks, and generated watchlists.

2. Run mirror validation:

```bash
PYTHONPATH=/path/to/public-mirror/timmy-trader \
  /path/to/timmy-trader/.venv/bin/pytest \
  /path/to/public-mirror/timmy-trader/tests
```

3. Check the staged diff:

```bash
git diff --cached --check
git status --short
```

4. Scan staged content for accidental credentials before commit.

5. Push and verify the remote head:

```bash
git push origin HEAD
git ls-remote origin HEAD
```

For the 0.1.6 native updater, publish a GitHub Release containing
`Timmy-linux-x86_64.tar.gz` and a matching `SHA256SUMS` asset. The Firebase
Download page offers `timmy-trader_0.1.6_amd64.deb` with its
`SHA256SUMS.txt`; verify both artifacts and their checksums before announcing
availability. Firebase Hosting publication and GitHub Release publication
are separate actions.

## 13. GitHub CI Workflow

The repository includes `.github/workflows/ci.yml` for source validation on pushes, pull requests, and manual dispatch.

CI performs:

- package install,
- Python module compilation,
- test suite,
- smoke test,
- source-only boundary check.

CI intentionally does not call live Webull endpoints, inspect account state, submit orders, or mutate watchlists. Those checks must run locally on the authorized machine.

## 14. Native GUI Model

The native GUI is organized around Timmy's model:

```text
Setup -> Universe -> Scanner -> Strategy -> Execution -> Broker -> Audit
```

- `Setup` is the Account Setup desk: Webull keys, account lane, Account Check,
  buying power, save gate, setup boilerplates, and local profile status.
- `Universe` is the known stock/ETF ticker pool and rotating market batch.
- `Scanner` is the ranked activity board.
- `Strategy` is the decision brief and eligibility explanation.
- `Execution` is the risk-capped order queue.
- `Broker` is the Webull check, preview, submit, and rejection surface.
- `Audit` is the local event trail for submitted, rejected, and paper events.

The top metric band should show the model state first: universe size, active list count, movement count, trade-ready count, executable plan count, and buying power.

Overview-only widgets such as the hero and pipeline metric band should stay
concise. Order controls and duplicated order-desk detail belong in `Execution`
as the Orders Ready surface; `Setup`, `Universe`, `Scanner`, `Strategy`,
`Execution`, `Broker`, and `Audit` should use the main content area for the
selected workflow surface.

Focused tabs should carry their own operational context:

- `Setup`: Account Setup for Webull keys, masked account ID, region/endpoint,
  live switches, verification, account picker, save profile, account check,
  setup boilerplates, setup readiness, and local profile/integrity file status.
- `Universe`: Market Pulse source, bundled snapshot counts, runtime cache,
  generated watchlists, and Webull watchlist-sync names.
- `Scanner`: Market Pulse ticker table with scanned, moving, tradeable, and
  blocked counts plus selected-symbol scout, price, and gate details.
- `Strategy`: Today's Guardrails for style/pattern/readiness summary, signal
  mix, decision brief, eligible symbols, watch focus, and model gates.
- `Execution`: Orders Ready desk with execution controls, target/queue/
  fractional/broker summary, run/preview/paper/live actions, executable queue
  details, preview freshness, broker gates, and risk blockers.
- `Broker`: Broker Desk for account/cash/live/preview summary, current account
  lane, cash/buying-power snapshot, live switches, preview state, account
  check state, and Webull route controls.
- `Audit`: Trade Log for integrity/event/live/rejected summary, audit-chain
  state, protected-file integrity, event totals, live/paper/rejected counts,
  and recent execution events.

Use icons only where the command is obvious: run, live submit, stop, and power
cycle. Keep text on higher-context actions such as scan, Account Check, and
route preview.

Account setup and switching are GUI workflows. The Account Setup surface should
verify the Webull profile before saving anything, save the verified profile
locally, show masked account labels discovered from verification or `Account
Check`, save the selected account locally, clear stale live previews, return
execution to `Paper`, and require a fresh account check before the user enables
`Live` for the newly selected account.

Setup boilerplates live in `docs/boilerplates/` and are example-only starters
for paper, guarded live, and runtime reliability settings. Opening boilerplates
from the Setup tab must not overwrite the local profile, bypass verification,
or introduce real broker credentials into source.

Tamper-resistance is also a GUI-visible workflow. Timmy signs execution events
into a local hash chain and keeps `.timmy-integrity.json` as a signed baseline
for protected runtime files. Timmy updates that baseline after its own profile,
settings, watchlist, journal, and event-log writes. If those files are edited
outside Timmy, the Trade Log should show a warning before the operator trusts
recent activity.

## 15. Redundant Widget Audit

Use this audit when the GUI starts to feel crowded or repetitive.

1. If a widget can mutate live, broker, account, order, or profile state, keep it on its owner tab only.

2. If a widget only explains current state, decide whether it is a summary or detail. Summaries may appear on `Overview`; details stay on the owner tab.

3. If two tabs show the same value, they must read from the same runtime source and use the same status vocabulary.

4. Remove duplicated action buttons before adding new shortcuts. Prefer one owner action plus a visible status summary elsewhere.

5. Audit these redundancy risks after each GUI upgrade:

```text
Overview copying Market Pulse tables
Overview copying Today's Guardrails decision logs
Overview copying Orders Ready controls
Overview copying Broker Desk raw responses
Overview copying Trade Log event history
Account Setup duplicating Broker Desk account route controls
Orders Ready duplicating Broker Desk credential verification
Trade Log duplicating Account Readiness one-click check output
Trading Scoreboard duplicating raw journals instead of summarizing them
```

# Review and operations workflow

Open **Review & Operations** from the left navigation to review local order
events, generate a UTC daily activity brief, inspect a read-only Webull open
order snapshot, and review reconciliation discrepancies. The order monitor has
no cancel or replace action because this application has not verified a safe
broker mutation contract. Each snapshot identifies the selected account with
only its final four characters and shows the current paper/live mode and local
snapshot time. A broker snapshot is time-bounded evidence; verify the current
order at Webull before acting.

The same workspace includes private, named configuration snapshots with hash
comparison and integrity-checked restore; a first-run checklist that explains
synthetic data, paper simulation, real account reads, and gated live trading;
separate journal review labels and notes; event-based recovery steps; and a
structured diagnostics export. Configuration snapshots can contain local broker
credentials and remain in Timmy's private runtime directory. Restoring one
requires restarting Timmy.

Alert preferences affect only the local status-bar notification. Quiet hours
do not suppress recorded alert events and do not affect trading. Timmy does not
currently provide email, SMS, push, or background alert delivery. Support
exports include allowlisted status fields and structured event summaries only;
they omit arbitrary event messages, broker order IDs, and raw crash logs.
